package problem4;

import java.util.Scanner;

public abstract class Shape 
{
	double height;
	double width;
		
	public abstract void get_data ();
		
	public abstract void display_area ();

}
