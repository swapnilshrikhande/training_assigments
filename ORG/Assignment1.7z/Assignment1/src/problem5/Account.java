package problem5;

public class Account 
{
	String customerName;
	int accountNumber;
	String typeOfAccount;
	
}
