package problem3;

public class Student 
{
	int roll_no;
	

}
